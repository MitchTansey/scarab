#ifndef _BIMODAL_H_
#define _BIMODAL_H_

class BIMODAL
{
private:
    
};

#endif